This directory contains the files belonging to the SQLite3 encryption
extension provided by wxSQLite3.

There is now support for Premake (http://http://premake.github.io/).
Premake 5.0-alpha11 or higher is recommended.

Precompiled SQLite3 binaries for Windows will be provided as separate
downloads.
